package progetto.mp.yang.lorenzo.freemediaplatform.utils;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.List;

import org.junit.Test;

import progetto.mp.yang.lorenzo.freemediaplatform.content.Content;
import progetto.mp.yang.lorenzo.freemediaplatform.content.Episode;
import progetto.mp.yang.lorenzo.freemediaplatform.content.Movie;
import progetto.mp.yang.lorenzo.freemediaplatform.content.Season;
import progetto.mp.yang.lorenzo.freemediaplatform.content.TVSeries;
import progetto.mp.yang.lorenzo.freemediaplatform.content.VideoResolution;

public class DisplayContentVisitorTest {
	@Test
	public void testVisitMovieRunsCorrectly() {
		Content movie = new Movie.MovieBuilder("Movie", new Episode(1, 120))
				.withDescription("Movie description")
				.withReleaseDate(LocalDate.of(2025, 1, 1))
				.withResolution(VideoResolution.FULL_HD_1080P)
				.build();

		String expected = "Movie: Movie\n" + "  Description: Movie description\n" + "  Release Date: 01-01-2025\n"
				+ "  Resolution: 1080p\n" + "  Total Duration: 120 minutes\n";

		assertEquals(expected, movie.accept(new DisplayContentVisitor()));
	}

	@Test
	public void testVisitTVSeriesRunsCorrectly() {
		var season1 = new Season(1, List.of(new Episode(1, 20)));
		var season2 = new Season(2, List.of(new Episode(1, 20)));

		Content tvSeries = new TVSeries.TVSeriesBuilder("TVSeries", season1)
				.withDescription("TVSeries description")
				.withReleaseDate(LocalDate.of(2025, 1, 1))
				.withResolution(VideoResolution.FULL_HD_1080P)
				.withSeason(season2)
				.build();

		String expected = "TV Series: TVSeries\n" + "  Description: TVSeries description\n"
				+ "  Release Date: 01-01-2025\n" + "  Resolution: 1080p\n" + "  Total Duration: 40 minutes\n"
				+ "Season 1\n" + "  Total Duration: 20 minutes\n" + "  Episode 1, Duration: 20 minutes\n" + "Season 2\n"
				+ "  Total Duration: 20 minutes\n" + "  Episode 1, Duration: 20 minutes\n";

		assertEquals(expected, tvSeries.accept(new DisplayContentVisitor()));
	}
}