package progetto.mp.yang.lorenzo.freemediaplatform.utils;

public interface EmailNotificationService {
	void notifyUser(String email, String subject, String message);
}
