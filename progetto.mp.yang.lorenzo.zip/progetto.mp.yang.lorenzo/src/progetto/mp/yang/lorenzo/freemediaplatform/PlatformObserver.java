package progetto.mp.yang.lorenzo.freemediaplatform;

import progetto.mp.yang.lorenzo.freemediaplatform.events.PlatformEvent;

public interface PlatformObserver {
	void notifyChange(PlatformEvent event);
}
