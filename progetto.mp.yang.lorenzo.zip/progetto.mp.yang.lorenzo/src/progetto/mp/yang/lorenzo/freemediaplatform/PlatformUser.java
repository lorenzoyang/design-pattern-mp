package progetto.mp.yang.lorenzo.freemediaplatform;

import java.util.Objects;

import progetto.mp.yang.lorenzo.freemediaplatform.events.AddContentEvent;
import progetto.mp.yang.lorenzo.freemediaplatform.events.PlatformEvent;
import progetto.mp.yang.lorenzo.freemediaplatform.events.UpdateContentEvent;
import progetto.mp.yang.lorenzo.freemediaplatform.utils.EmailNotificationService;
import progetto.mp.yang.lorenzo.freemediaplatform.utils.PlatformEventVisitorAdapter;

public class PlatformUser implements PlatformObserver {
	private final String email;
	private final EmailNotificationService emailNotificationService;

	public PlatformUser(String email, EmailNotificationService emailNotificationService) {
		Objects.requireNonNull(email, "Email cannot be null");
		if (email.isBlank() || !email.contains("@")) {
			throw new IllegalArgumentException("Invalid email address");
		}
		this.email = email;

		Objects.requireNonNull(emailNotificationService, "EmailNotificationService cannot be null");
		this.emailNotificationService = emailNotificationService;
	}

	@Override
	public void notifyChange(PlatformEvent event) {
		event.accept(new PlatformEventVisitorAdapter() {
			@Override
			public void visitAddContent(AddContentEvent event) {
				String notificationMsg = "New content added: " + event.getAddedContent().getTitle()
						+ ". Check your email for details.";
				emailNotificationService.notifyUser(email, "New Content Added", notificationMsg);
			}

			@Override
			public void visitUpdateContent(UpdateContentEvent event) {
				String notificationMsg = "Content updated: " + event.getUpdatedContent().getTitle()
						+ ". Check your email for details.";
				emailNotificationService.notifyUser(email, "Content Updated", notificationMsg);
			}
		});
	}
}
