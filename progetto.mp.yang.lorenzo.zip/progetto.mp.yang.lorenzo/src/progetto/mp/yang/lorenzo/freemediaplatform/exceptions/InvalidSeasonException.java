package progetto.mp.yang.lorenzo.freemediaplatform.exceptions;

public class InvalidSeasonException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public InvalidSeasonException(String message) {
		super(message);
	}
}
