package progetto.mp.yang.lorenzo.freemediaplatform.utils;

import progetto.mp.yang.lorenzo.freemediaplatform.events.AddContentEvent;
import progetto.mp.yang.lorenzo.freemediaplatform.events.RemoveContentEvent;
import progetto.mp.yang.lorenzo.freemediaplatform.events.UpdateContentEvent;

public abstract class PlatformEventVisitorAdapter implements PlatformEventVisitor {
	@Override
	public void visitAddContent(AddContentEvent event) {
		// default implementation
	}

	@Override
	public void visitRemoveContent(RemoveContentEvent event) {
		// default implementation
	}

	@Override
	public void visitUpdateContent(UpdateContentEvent event) {
		// default implementation
	}
}
