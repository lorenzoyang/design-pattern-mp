package progetto.mp.yang.lorenzo.freemediaplatform.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import progetto.mp.yang.lorenzo.freemediaplatform.content.Episode;
import progetto.mp.yang.lorenzo.freemediaplatform.content.Movie;
import progetto.mp.yang.lorenzo.freemediaplatform.content.Season;
import progetto.mp.yang.lorenzo.freemediaplatform.content.TVSeries;

public class PlaybackContentVisitor implements ContentVisitor<Iterable<Episode>> {
	@Override
	public Iterable<Episode> visitMovie(Movie movie) {
		return List.of(movie.getEpisode());
	}

	@Override
	public Iterable<Episode> visitTVSeries(TVSeries tvSeries) {
		Collection<Episode> allEpisodes = new ArrayList<>();
		for (Season season : tvSeries) {
			season.iterator().forEachRemaining(allEpisodes::add);
		}
		return allEpisodes;
	}
}
