package progetto.mp.yang.lorenzo.freemediaplatform.exceptions;

public class StreamingPlatformException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public StreamingPlatformException(String message) {
		super(message);
	}
}
