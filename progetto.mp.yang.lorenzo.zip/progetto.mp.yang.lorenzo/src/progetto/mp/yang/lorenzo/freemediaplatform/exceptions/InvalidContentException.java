package progetto.mp.yang.lorenzo.freemediaplatform.exceptions;

public class InvalidContentException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public InvalidContentException(String message) {
		super(message);
	}
}