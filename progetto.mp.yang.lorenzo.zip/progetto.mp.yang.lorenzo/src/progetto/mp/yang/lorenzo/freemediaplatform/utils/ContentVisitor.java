package progetto.mp.yang.lorenzo.freemediaplatform.utils;

import progetto.mp.yang.lorenzo.freemediaplatform.content.Movie;
import progetto.mp.yang.lorenzo.freemediaplatform.content.TVSeries;

public interface ContentVisitor<T> {
	T visitMovie(Movie movie);

	T visitTVSeries(TVSeries tvSeries);
}
