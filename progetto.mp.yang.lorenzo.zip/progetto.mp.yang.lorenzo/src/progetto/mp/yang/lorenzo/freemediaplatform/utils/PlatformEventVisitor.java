package progetto.mp.yang.lorenzo.freemediaplatform.utils;

import progetto.mp.yang.lorenzo.freemediaplatform.events.AddContentEvent;
import progetto.mp.yang.lorenzo.freemediaplatform.events.RemoveContentEvent;
import progetto.mp.yang.lorenzo.freemediaplatform.events.UpdateContentEvent;

public interface PlatformEventVisitor {
	void visitAddContent(AddContentEvent event);

	void visitRemoveContent(RemoveContentEvent event);

	void visitUpdateContent(UpdateContentEvent event);
}
