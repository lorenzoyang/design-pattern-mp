package progetto.mp.yang.lorenzo.freemediaplatform.events;

import progetto.mp.yang.lorenzo.freemediaplatform.utils.PlatformEventVisitor;

public interface PlatformEvent {
	void accept(PlatformEventVisitor visitor);
}
