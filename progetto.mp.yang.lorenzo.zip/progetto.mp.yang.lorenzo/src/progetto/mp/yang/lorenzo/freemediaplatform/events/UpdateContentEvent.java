package progetto.mp.yang.lorenzo.freemediaplatform.events;

import progetto.mp.yang.lorenzo.freemediaplatform.content.Content;
import progetto.mp.yang.lorenzo.freemediaplatform.utils.PlatformEventVisitor;

public class UpdateContentEvent implements PlatformEvent {
	private final Content oldContent;
	private final Content updatedContent;

	public UpdateContentEvent(Content oldContent, Content updatedContent) {
		this.oldContent = oldContent;
		this.updatedContent = updatedContent;
	}

	public Content getOldContent() {
		return oldContent;
	}

	public Content getUpdatedContent() {
		return updatedContent;
	}

	@Override
	public void accept(PlatformEventVisitor visitor) {
		visitor.visitUpdateContent(this);
	}
}
