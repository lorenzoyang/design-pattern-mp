package progetto.mp.yang.lorenzo.freemediaplatform.events;

import progetto.mp.yang.lorenzo.freemediaplatform.content.Content;
import progetto.mp.yang.lorenzo.freemediaplatform.utils.PlatformEventVisitor;

public class RemoveContentEvent implements PlatformEvent {
	private final Content removedContent;

	public RemoveContentEvent(Content removedContent) {
		this.removedContent = removedContent;
	}

	public Content getRemovedContent() {
		return removedContent;
	}

	@Override
	public void accept(PlatformEventVisitor visitor) {
		visitor.visitRemoveContent(this);
	}
}
